export interface UserFormat {
    currBalance: number,
    accType: string,
    accHolderName: string
}