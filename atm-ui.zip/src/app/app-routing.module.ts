import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { UserTypeComponent } from './user-type/user-type.component';
import { ProcessingComponent } from './processing/processing.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const routes: Routes = [
  {path: '', redirectTo: '/home', pathMatch:'full'},
  {path: 'home', component: HomeComponent },
  {path: 'processing', component: ProcessingComponent },
  {path: 'withdraw', component: WithdrawComponent },
  {path: 'userType', component: UserTypeComponent },
  {path: 'not-found', component: PageNotFoundComponent },
  {path: '**', redirectTo: '/not-found' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
