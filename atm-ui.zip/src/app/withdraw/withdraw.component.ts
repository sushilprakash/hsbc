import { Component, OnInit } from '@angular/core';
import { UserFormat } from './../../shared/user.model';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  constructor() { }

  userDetails: UserFormat = {currBalance : 4500, accType : 'saving', accHolderName: 'Ayushman'};

  withdrawAmt: number;




  ngOnInit() {
  }

}
