import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProcessingComponent } from './processing/processing.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HomeComponent } from './home/home.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { UserTypeComponent } from './user-type/user-type.component';
import { CardFormatPipe } from './../shared/card-format.pipe';

@NgModule({
  declarations: [
    AppComponent,
    ProcessingComponent,
    PageNotFoundComponent,
    HomeComponent,
    WithdrawComponent,
    UserTypeComponent,
    CardFormatPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
