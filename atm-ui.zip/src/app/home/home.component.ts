import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private router: Router) { }

  plainCreditCard:string = '555555555555';
  onSubmit(){
      this.router.navigate(['/userType']);
    }

    ngOnInit() {
    }
}
